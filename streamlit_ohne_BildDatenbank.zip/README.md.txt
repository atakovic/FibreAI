Github-Link: https://github.com/atakovic/streamlit

Starten über Pycharm:
1. Drücke links oben neben den Pycharm-Logo auf den Button mit den 4 Strichen
1. Danach gehe auf Run -> Edit Configurations
1. Drücke auf das "+" Symbol und wähle Python aus
1. Im Feld Name, kannst du einen beliebigen Namen auswählen. Meine Empfehlung ist "Name: run streamlit".
1. Wähle im ersten Feld Python 3.10 aus (Hinweis: Es sollte zuvor Python 3.10.6 heruntergeladen worden sein)
1. Wähle im zweiten Feld: module statt script und schreibe daneben "streamlit"
1. Schreibe im dritten Feld: run + den Pfad zur app.py Datei. Beispiel (run C:\Users\Hellweg\Documents\streamlit\app.py)
1. Drücke im Feld "Working Directory:" auf das Dokumenten-Symbol und wähle aus: $ProjectFileDir$
1. Drücke unten auf OK und nun kannst du, nach dem das Fenster geschlossen ist, oben auf PLAY drücken. Dann sollte dein Programm automatisch starten.

**Du findest auch ein Screenshot der Konfiguration unter Beispielbild_1.**

**Hinweis:**
Sollte Streamlit eine Meldung machen zu einer E-Mail (siehe Beispielbild_2), dann drücke einfach nur ENTER. Danach sollte sich das Programm per Browser automatisch öffnen, bzw. durch die zwei vorgegeben Links im Terminal (siehe Beispielbild_3) öffnen lassen.
